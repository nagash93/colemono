<?php
/**
 * @package WordPress
 * @subpackage Evolutionary
 */

get_header(); ?>

	<div id="main">
			<div id="content">
			
			<h2 class="pagetitle">Error 404 - Not Found</h2>
		</div>

<?php get_sidebar(); ?>

	</div>
<?php get_footer(); ?>

</div>