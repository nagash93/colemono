		<!-- BEGIN SIDEBAR -->
		<div id="sidebar">
		
			<?php	/* Widgetised Area */	if ( !function_exists( 'dynamic_sidebar' ) || !dynamic_sidebar() ) ?>
	
		</div>
		<!-- END SIDEBAR -->

	</div>
	<!-- END MAIN-WRAPPER -->